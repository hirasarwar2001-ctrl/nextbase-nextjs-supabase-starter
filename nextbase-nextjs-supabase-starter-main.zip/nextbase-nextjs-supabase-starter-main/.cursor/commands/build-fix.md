Build

# Overview build the project

## Build the project 

Use pnpm build to build the project and fix build errors.