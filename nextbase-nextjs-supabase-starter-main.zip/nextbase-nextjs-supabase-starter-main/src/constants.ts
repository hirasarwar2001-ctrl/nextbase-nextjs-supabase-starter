export const DEV_PORT = 3000;
export const PRODUCT_NAME = 'NextBase Open-Source Starter';
