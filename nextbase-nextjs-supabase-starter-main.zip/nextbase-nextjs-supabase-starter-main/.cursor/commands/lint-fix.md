Lint Fix

# Overview 
Lint the project using pnpm lint

## Lint the project 

Use pnpm lint the project and if there any errors, fix the errors. Ignore fixing the warnings unless requsted to fix them.