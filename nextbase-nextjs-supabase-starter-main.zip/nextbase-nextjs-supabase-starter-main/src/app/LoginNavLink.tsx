'use client';
import { NavLink } from './NavLink';

export function LoginNavLink() {
  return <NavLink href="/login">Login</NavLink>;
}
