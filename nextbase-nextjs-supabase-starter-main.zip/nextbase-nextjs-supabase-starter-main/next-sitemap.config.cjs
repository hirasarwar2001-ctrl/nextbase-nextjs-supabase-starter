/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://my-awesome-saas.com', // FIXME: Change to your production URL
  generateRobotsTxt: true,
};
