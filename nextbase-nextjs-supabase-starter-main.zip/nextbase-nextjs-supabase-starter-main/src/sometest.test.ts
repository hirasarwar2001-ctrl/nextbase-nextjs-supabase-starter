import { expect, test } from 'vitest';

test('fake test', () => {
  expect(true).toBe(true);
});
