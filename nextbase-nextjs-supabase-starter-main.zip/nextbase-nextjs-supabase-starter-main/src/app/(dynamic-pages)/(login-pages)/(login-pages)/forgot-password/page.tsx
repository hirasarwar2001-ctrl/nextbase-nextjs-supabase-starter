import { ForgotPassword } from './ForgotPassword';

export default function ForgotPasswordPage() {
  return <ForgotPassword />;
}
