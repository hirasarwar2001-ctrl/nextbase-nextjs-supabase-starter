Typescript Fix

# Overview 
Test the types in project using pnpm tsc

## Check the types of the project 

Use pnpm tsc on the project and if there any errors, fix the errors. Ignore fixing the warnings unless requsted to fix them.